let count = localStorage.getItem("count") || 0;

const counter = document.getElementById("counter");

updateDisplay();

function updateDisplay(){

counter.textContent = count;

counter.style.transform="scale(1.2)";

setTimeout(()=>{
counter.style.transform="scale(1)";
},150);

localStorage.setItem("count",count);

}

function increase(){

count++;
updateDisplay();

}

function decrease(){

count--;
updateDisplay();

}

function resetCount(){

if(confirm("هل أنت متأكد من إعادة العداد؟")){

count=0;
updateDisplay();

}

}

function toggleDarkMode(){

document.body.classList.toggle("dark");

}